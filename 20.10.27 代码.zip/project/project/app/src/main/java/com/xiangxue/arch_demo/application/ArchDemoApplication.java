package com.xiangxue.arch_demo.application;

import android.app.Application;
import android.content.Context;
import android.os.Debug;
import android.os.Environment;


import com.arch.demo.core.loadsir.CustomCallback;
import com.arch.demo.core.loadsir.EmptyCallback;
import com.arch.demo.core.loadsir.ErrorCallback;
import com.arch.demo.core.loadsir.LoadingCallback;
import com.arch.demo.core.loadsir.TimeoutCallback;
import com.arch.demo.core.preference.PreferencesUtil;
import com.arch.demo.core.utils.ToastUtil;
import com.kingja.loadsir.core.LoadSir;
import com.xiangxue.arch_demo.blockcanary.BlockCanary;
import com.xiangxue.network.base.NetworkApi;


import java.io.File;

import dagger.hilt.android.HiltAndroidApp;

/**
 * Created by Allen on 2017/7/20.
 * 保留所有版权，未经允许请不要分享到互联网和其他人
 */
@HiltAndroidApp
public class ArchDemoApplication extends Application {

    public ArchDemoApplication() {
//        Debug.startMethodTracingSampling(new File(Environment.getExternalStorageDirectory(),
//                "enjoy").getAbsolutePath(), 8 * 1024 * 1024, 1_000);
//        Debug.startMethodTracing(new File(Environment.getExternalStorageDirectory(),
//                "enjoy").getAbsolutePath());
    }



    @Override
    public void onCreate() {
        super.onCreate();
        PreferencesUtil.init(this);
        NetworkApi.init(new NetworkRequestInfo(this));
        ToastUtil.init(this);
        LoadSir.beginBuilder()
                .addCallback(new ErrorCallback())//添加各种状态页
                .addCallback(new EmptyCallback())
                .addCallback(new LoadingCallback())
                .addCallback(new TimeoutCallback())
                .addCallback(new CustomCallback())
                .setDefaultCallback(LoadingCallback.class)//设置默认状态页
                .commit();

        BlockCanary.install();
    }
}
