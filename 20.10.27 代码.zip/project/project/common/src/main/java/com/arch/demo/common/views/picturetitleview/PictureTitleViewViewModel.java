package com.arch.demo.common.views.picturetitleview;

import com.arch.demo.core.customview.BaseCustomViewModel;

/**
 * Created by Allen on 2017/7/20.
 * 保留所有版权，未经允许请不要分享到互联网和其他人
 */
public class PictureTitleViewViewModel extends BaseCustomViewModel {
    public String avatarUrl;
    public String title;
}