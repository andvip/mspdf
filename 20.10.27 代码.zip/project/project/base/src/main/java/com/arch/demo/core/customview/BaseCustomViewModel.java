package com.arch.demo.core.customview;

import java.io.Serializable;

public class BaseCustomViewModel implements Serializable {
    public String jumpUri;
}
