package com.leo.skinlib;

public interface SkinViewSupport {

    void applySkin();
}
